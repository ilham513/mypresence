<?php
// extends class Model
class Api_model extends CI_Model{
	##GAK KEPAKE WKWKW
}	
?>